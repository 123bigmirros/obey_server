# from llmtuner import ChatModel
# from llmtuner.extras.misc import torch_gc
# import pandas as pd

# try:
#     import platform

#     if platform.system() != "Windows":
#         import readline  # noqa: F401
# except ImportError:
#     print("Install `readline` for a better experience.")
# df = pd.read_csv("/home/dymiao/data/project/LLaMA-Factory-main/src/大模型公共小组_3_测试结果文件.csv")
# datas = df['input']

# def main():
#     chat_model = ChatModel()
#     messages = []
#     print("Welcome to the CLI application, use `clear` to remove the history, use `exit` to exit the application.")
#     for i,data in enumerate(datas):
        
#         messages = []
#         data = eval(data)
#         for d in data:
#             if i==0:
#                 messages.append({"role":"user","content":"现在你是一位工业品智能采购助手，与有购买需求的用户交流，帮助用户厘清采购的工业品型号及其技术属性。用户的提问如下：\n"+d['user']})
#             else:
#                 messages.append({"role":"user","content":d['user']})
#             messages.append({"role":"assistant","content":"请继续叙述您的需求，以便为您更好的服务。"})
#         messages.append({"role":"user","content":"[Agent] result = Summary()"})
#         response = ""
#         for new_text in chat_model.stream_chat(messages):
#             print(new_text, end="", flush=True)
#             response += new_text
#         print()

# if __name__ == "__main__":
#     main()
from llmtuner import ChatModel
from llmtuner.extras.misc import torch_gc


try:
    import platform

    if platform.system() != "Windows":
        import readline  # noqa: F401
except ImportError:
    print("Install `readline` for a better experience.")


def main():
    chat_model = ChatModel()
    messages = []
    print("Welcome to the CLI application, use `clear` to remove the history, use `exit` to exit the application.")

    while True:
        try:
            query = input("\nUser: ")
        except UnicodeDecodeError:
            print("Detected decoding error at the inputs, please set the terminal encoding to utf-8.")
            continue
        except Exception:
            raise

        if query.strip() == "exit":
            break

        if query.strip() == "clear":
            messages = []
            torch_gc()
            print("History has been removed.")
            continue

        messages.append({"role": "user", "content": query})
        print("Assistant: ", end="", flush=True)

        response = ""
        for new_text in chat_model.stream_chat(messages):
            print(new_text, end="", flush=True)
            response += new_text
        print()
        messages.append({"role": "assistant", "content": response})


if __name__ == "__main__":
    main()