import json
import os
from typing import TYPE_CHECKING, Any, Dict, Generator, List, Optional, Sequence, Tuple
import sys
sys.path.append('/home/dymiao/data/project/LLaMA-Factory-main/find_commodity')
import gradio as gr
import chzhao
from gradio.components import Component  # cannot use TYPE_CHECKING here

from ..chat import ChatModel
from ..data import Role
from ..extras.misc import torch_gc
from .common import get_save_dir
from .locales import ALERTS
import re

def extract_bracket_content(text,history):
    start_index = text.find('{')
    if start_index == -1:
        return None
    
    count = 1
    end_index = start_index + 1
    while end_index < len(text) and count > 0:
        if text[end_index] == '{':
            count += 1
        elif text[end_index] == '}':
            count -= 1
        end_index += 1
    
    if count != 0:
        return None
    
    data = eval(text[start_index:end_index])
    keys = list(data.keys())
    for key in keys:
        if key == '采购品类' :
            continue
        flag = True 
        for talk in history:
            if key in talk['content']:
                flag = False  
                break
        if flag:
            del data[key]
    return str(data)
def replace_substring(input_str, sub_str):
    # 检查子字符串是否存在
    if sub_str in input_str:
        # 将子字符串替换为空
        input_str = input_str.replace(sub_str, "")
    return input_str
def manage_result(result,history):
    data = extract_bracket_content(result,history)
    data = eval(data)
    rte = {'品类要求':data.get('采购品类','未知'),'技术属性要求':{}}
    for key in data.keys():
        if key=='采购品类':
            continue
        rte['技术属性要求'][key] = data[key]
    return rte
if TYPE_CHECKING:
    from ..chat import BaseEngine
    from .manager import Manager


class WebChatModel(ChatModel):
    def __init__(self, manager: "Manager", demo_mode: bool = False, lazy_init: bool = True) -> None:
        self.manager = manager
        self.demo_mode = demo_mode
        self.engine: Optional["BaseEngine"] = None

        if not lazy_init:  # read arguments from command line
            super().__init__()

        if demo_mode and os.environ.get("DEMO_MODEL") and os.environ.get("DEMO_TEMPLATE"):  # load demo model
            model_name_or_path = os.environ.get("DEMO_MODEL")
            template = os.environ.get("DEMO_TEMPLATE")
            super().__init__(dict(model_name_or_path=model_name_or_path, template=template))

    @property
    def loaded(self) -> bool:
        return self.engine is not None

    def load_model(self, data: Dict[Component, Any]) -> Generator[str, None, None]:
        get = lambda elem_id: data[self.manager.get_elem_by_id(elem_id)]
        lang = get("top.lang")
        error = ""
        if self.loaded:
            error = ALERTS["err_exists"][lang]
        elif not get("top.model_name"):
            error = ALERTS["err_no_model"][lang]
        elif not get("top.model_path"):
            error = ALERTS["err_no_path"][lang]
        elif self.demo_mode:
            error = ALERTS["err_demo"][lang]

        if error:
            gr.Warning(error)
            yield error
            return

        if get("top.adapter_path"):
            adapter_name_or_path = ",".join(
                [
                    get_save_dir(get("top.model_name"), get("top.finetuning_type"), adapter)
                    for adapter in get("top.adapter_path")
                ]
            )
        else:
            adapter_name_or_path = None

        yield ALERTS["info_loading"][lang]
        args = dict(
            model_name_or_path=get("top.model_path"),
            adapter_name_or_path=adapter_name_or_path,
            finetuning_type=get("top.finetuning_type"),
            quantization_bit=int(get("top.quantization_bit")) if get("top.quantization_bit") in ["8", "4"] else None,
            template=get("top.template"),
            flash_attn=(get("top.booster") == "flash_attn"),
            use_unsloth=(get("top.booster") == "unsloth"),
            rope_scaling=get("top.rope_scaling") if get("top.rope_scaling") in ["linear", "dynamic"] else None,
            infer_backend=get("infer.infer_backend"),
        )
        super().__init__(args)

        yield ALERTS["info_loaded"][lang]

    def unload_model(self, data: Dict[Component, Any]) -> Generator[str, None, None]:
        lang = data[self.manager.get_elem_by_id("top.lang")]

        if self.demo_mode:
            gr.Warning(ALERTS["err_demo"][lang])
            yield ALERTS["err_demo"][lang]
            return

        yield ALERTS["info_unloading"][lang]
        self.engine = None
        torch_gc()
        yield ALERTS["info_unloaded"][lang]

    def predict(
        self,
        chatbot: List[Tuple[str, str]],
        role: str,
        query: str,
        messages: Sequence[Dict[str, str]],
        # system: str,

        max_new_tokens: int,
        top_p: float,
        temperature: float,
    ) -> Generator[Tuple[List[Tuple[str, str]], List[Dict[str, str]]], None, None]:
        system = '现在你是一位工业品智能采购助手，与有购买需求的用户交流，帮助用户厘清采购的工业品型号及其技术属性。用户的提问如下：\n'
        if '[Agent] result = Recommend()' in query:
            return self.recommend(chatbot,role,query,messages,system,max_new_tokens,top_p,temperature)
        elif '[Agent] result = Summary()' in query:
            return self.summary(chatbot,role,query,messages,system,max_new_tokens,top_p,temperature)
        chatbot.append([query, ""])
        query_messages = []

        for i in range(0,len(messages),2):
            if messages[i]['content']=='[Agent] result = Summary()' or messages[i]['content']=='[Agent] result = Recommend()':
                continue
            elif '[Agent] result = Summary()' in messages[i]['content'] or '[Agent] result = Recommend()' in messages[i]['content']:
                tmp = replace_substring(messages[i]['content'],'[Agent] result = Summary()') 
                tmp = replace_substring(tmp,'[Agent] result = Recommend()')
                query_messages = query_messages+[{'role':'user','content':tmp}] 
                query_messages = query_messages + [{'role':'assistant','content':messages[i+1]['content']}]
            else:   
                query_messages = query_messages+[{'role':'user','content':messages[i]['content']}] 
                query_messages = query_messages + [{'role':'assistant','content':messages[i+1]['content']}]
        
        query_messages = query_messages+ [{"role": 'user', "content": query}]
        print(query_messages)
        response = ""
        for new_text in self.stream_chat(
            query_messages, system, "", max_new_tokens=max_new_tokens, top_p=top_p, temperature=temperature
        ):
            response += new_text
            # if tools:
            #     result = self.engine.template.format_tools.extract(response)
            # else:
            result = response
            if '采购品类' in result:
                result.replace('采购品类','品类要求')
            if isinstance(result, tuple):
                name, arguments = result
                arguments = json.loads(arguments)
                tool_call = json.dumps({"name": name, "arguments": arguments}, ensure_ascii=False)
                output_messages = query_messages + [{"role": Role.FUNCTION.value, "content": tool_call}]
                bot_text = "```json\n" + tool_call + "\n```"
            else:
                output_messages = query_messages + [{"role": Role.ASSISTANT.value, "content": result}]
                bot_text = result

            chatbot[-1] = [query, str(bot_text)]
            yield chatbot, output_messages
    def summary(
        self,
        chatbot: List[Tuple[str, str]],
        role: str,
        query: str,
        messages: Sequence[Dict[str, str]],
        # system: str,
        max_new_tokens: int,
        top_p: float,
        temperature: float,
    ) -> Generator[Tuple[List[Tuple[str, str]], List[Dict[str, str]]], None, None]:
        system = '现在你是一位工业品智能采购助手，与有购买需求的用户交流，帮助用户厘清采购的工业品型号及其技术属性。用户的提问如下：\n'
        if query=="":
            query = '[Agent] result = Summary()'
            tmp_query = query
        else:
            tmp_query = query
            
        chatbot.append([tmp_query, ""])
        query_messages = []
        for i in range(0,len(messages),2):
            if messages[i]['content']=='[Agent] result = Summary()' or messages[i]['content']=='[Agent] result = Recommend()':
                continue
            elif '[Agent] result = Summary()' in messages[i]['content'] or '[Agent] result = Recommend()' in messages[i]['content']:
                tmp = replace_substring(messages[i]['content'],'[Agent] result = Summary()') 
                tmp = replace_substring(tmp,'[Agent] result = Recommend()')
                query_messages = query_messages+[{'role':'user','content':tmp}] 
                query_messages = query_messages + [{'role':'assistant','content':""}]
            else:   
                query_messages = query_messages+[{'role':'user','content':messages[i]['content']}] 
                query_messages = query_messages + [{'role':'assistant','content':""}]
        
        query_messages = query_messages+ [{"role": 'user', "content": query}]
        response,response2 = "",""
        for new_text in self.stream_chat(
            query_messages, system, "", max_new_tokens=max_new_tokens, top_p=top_p, temperature=temperature
        ):
            response += new_text
            
        bot_text = str(manage_result(response,query_messages))
        output_messages = query_messages + [{"role": Role.ASSISTANT.value, "content": str(bot_text)}]
        chatbot[-1] = [query, str(bot_text)]
        return  chatbot, output_messages
    def recommend(
        self,
        chatbot: List[Tuple[str, str]],
        role: str,
        query: str,
        messages: Sequence[Dict[str, str]],
        # system: str,
        max_new_tokens: int,
        top_p: float,
        temperature: float,
    ) -> Generator[Tuple[List[Tuple[str, str]], List[Dict[str, str]]], None, None]:
        system = '现在你是一位工业品智能采购助手，与有购买需求的用户交流，帮助用户厘清采购的工业品型号及其技术属性。用户的提问如下：\n'
        tmp_query = query
        if query=="":
            query = '[Agent] result = Recommend()'
            tmp_query = query
        else:
            tmp_query = query
            query = query.replace('[Agent] result = Summary()','')
            query = query.replace('[Agent] result = Recommend()','[Agent] result = Summary()')
        
        chatbot.append([tmp_query, ""])
        query_messages = []

        for i in range(0,len(messages),2):
            if messages[i]['content']=='[Agent] result = Summary()' or messages[i]['content']=='[Agent] result = Recommend()':
                continue
            elif '[Agent] result = Summary()' in messages[i]['content'] or '[Agent] result = Recommend()' in messages[i]['content']:
                tmp = replace_substring(messages[i]['content'],'[Agent] result = Summary()') 
                tmp = replace_substring(tmp,'[Agent] result = Recommend()')
                query_messages = query_messages+[{'role':'user','content':tmp}] 
                query_messages = query_messages + [{'role':'assistant','content':""}]
            else:   
                query_messages = query_messages+[{'role':'user','content':messages[i]['content']}] 
                query_messages = query_messages + [{'role':'assistant','content':""}]
        
        query_messages = query_messages+ [{"role": 'user', "content": query}]
        response = ""
        for new_text in self.stream_chat(
            query_messages, system, "", max_new_tokens=max_new_tokens, top_p=top_p, temperature=temperature
        ):
            response += new_text
            
        bot_text,items =chzhao.find_commody(eval(extract_bracket_content(response,query_messages)))
        bot_text = str(bot_text)
        output_messages = query_messages + [{"role": Role.ASSISTANT.value, "content": str(bot_text)}]
        for item in items:
            bot_text = bot_text+'\n'
            bot_text = bot_text+str(item)
        chatbot[-1] = [tmp_query, str(bot_text)]
        return  chatbot, output_messages