from llmtuner import Evaluator


def main():
    Evaluator().eval()


if __name__ == "__main__":
    main()
